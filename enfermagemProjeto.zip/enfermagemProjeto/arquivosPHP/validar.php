<?php
include "conexaoBanco.php";
include "funcoesPHP.php";
include "editar.php";
include "excluir.php";

$email = $_POST["email"]; 
$senha = $_POST["senha"];
$tipo = $_POST["tipo"]; 

// Ação de login/cadastro
if (isset($_GET["acao"]) && $_GET["acao"] === "login") {
    logar($email, $senha, $conn);
}

// Ação de registro
if (isset($_GET["acao"]) && $_GET["acao"] === "cadastro") {
    cadastrar($email, $senha, $conn, $tipo);
}

?>