<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="salvar.php" method="post">

        <input id="nome" name="nome">
        <p class="erros"></p>

        <input id="bula" name="bula">
        <p class="erros"></p>

        <input id="publicoAlvo" name="publicoAlvo">
        <p class="erros"></p>

        <input id="precaucoes" name="precaucoes">
        <p class="erros"></p>

        <input id="contraIndicacoes" name="contraIndicacoes">
        <p class="erros"></p>

        <input id="composicao" name="composicao">
        <p class="erros"></p>

        <input id="efeitos" name="efeitos">
        <p class="erros"></p>

    <button type="submit">Salvar</button>

</form>
<script src="js/formValidation.js"></script>
</body>
</html>
