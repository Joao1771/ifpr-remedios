// const email = document.querySelector("#email");
// const password = document.querySelector("#password");
// const erros = document.querySelectorAll(".erros");
// const form = document.querySelector("form");
// const params = new URLSearchParams(window.location.search);

// const erroVazio = "Por favor, insira as informações.";
// const erroMin5 = "A senha deve ter no mínimo 5 caracteres.";
// const erroEmailInvalido = "Digite um email válido (ex: email@email.com)";

// if (params.get("erro") === "1") {

//     document.querySelectorAll(".erros")[0].innerHTML =
//     "Email ou senha incorretos";
// }

// function clearErrors() {
//     erros.forEach(p => p.innerHTML = "");
// }

// function isValidEmail(value) {
//     return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
// }

// function verifyEmail() {
//     const value = email.value.trim();

//     if (value === "") {
//         erros[0].innerHTML = erroVazio;
//         return true;
//     }

//     if (!isValidEmail(value)) {
//         erros[0].innerHTML = erroEmailInvalido;
//         return true;
//     }

//     return false;
// }

// function verifyPassword() {
//     const value = password.value.trim();

//     if (value === "") {
//         erros[1].innerHTML = erroVazio;
//         return true;
//     }

//     if (value.length < 5) {
//         erros[1].innerHTML = erroMin5;
//         return true;
//     }

//     return false;
// }

// function login() {
//     form.addEventListener("submit", e => {
//         clearErrors();

//         const emailErro = verifyEmail();
//         const passwordErro = verifyPassword();

//         if (emailErro || passwordErro) {
//             e.preventDefault();
//         }
//     });
// }

// login();

const nome = document.querySelector("#nome");
const bula = document.querySelector("#bula");
const publicoAlvo = document.querySelector("#publicoAlvo");
const precaucoes = document.querySelector("#precaucoes");
const contraIndicacoes = document.querySelector("#contraIndicacoes");
const efeitos = document.querySelector("#efeitos");

const erros = document.querySelectorAll(".erros");
const form = document.querySelector("form");

const erroVazio = "Por favor, preencha este campo.";
const erroURL = "Digite uma URL válida (ex: https://site.com)";

function clearErrors() {
    erros.forEach(p => p.innerHTML = "");
}

function isValidURL(value) {
    return /^(https?:\/\/)[^\s$.?#].[^\s]*$/.test(value);
}

function verifyNome() {
    const value = nome.value.trim();

    if (value === "") {
        erros[0].innerHTML = erroVazio;
        return true;
    }

    return false;
}

function verifyBula() {
    const value = bula.value.trim();

    if (value === "") {
        erros[1].innerHTML = erroVazio;
        return true;
    }

    if (!isValidURL(value)) {
        erros[1].innerHTML = erroURL;
        return true;
    }

    return false;
}

function verifyCampo(campo, index) {
    const value = campo.value.trim();

    if (value === "") {
        erros[index].innerHTML = erroVazio;
        return true;
    }

    return false;
}

function validarFormulario() {
    form.addEventListener("submit", e => {
        clearErrors();

        const nomeErro = verifyNome();
        const bulaErro = verifyBula();
        const publicoErro = verifyCampo(publicoAlvo, 2);
        const precaucoesErro = verifyCampo(precaucoes, 3);
        const contraErro = verifyCampo(contraIndicacoes, 4);
        const efeitosErro = verifyCampo(efeitos, 5);

        if (nomeErro || bulaErro || publicoErro || precaucoesErro || contraErro || efeitosErro) {
            e.preventDefault();
        }
    });
}

validarFormulario();