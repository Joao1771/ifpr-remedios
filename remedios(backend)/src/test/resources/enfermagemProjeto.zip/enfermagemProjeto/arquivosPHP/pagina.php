<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tabela de Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h3> Lista de Produtos</h3>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark"">
            <tr>
                  
                    <th  style= "background-color: 	black; color: white;"> NOME </th>
                    <th style= "background-color: 	black; color: white;"> BULA </th>
                     <th style= "background-color: 	black; color: white;">PUBLICO_ALVO </th>
                    <th style= "background-color: 	black; color: white;"> PRECAUCOES </th>
                     <th style= "background-color: 	black; color: white;">CONTRA_INDICACOES </th>
                     <th style= "background-color: 	black; color: white;">COMPOSICAO</th>
                     <th style= "background-color: 	black; color: white;">EFEITOS</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include("conexaoBanco.php"); 

            $sql = "SELECT * FROM REMEDIOS";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                 
                    echo "<td>". $row['NOME'] ."</td>";
                    echo "<td>". $row['BULA'] ."</td>";
                    echo "<td>". $row['PUBLICO_ALVO'] ."</td>";
                    echo "<td>". $row['PRECAUCOES'] ."</td>";
                    echo "<td>". $row['CONTRA_INDICACOES'] ."</td>";
                    echo "<td>". $row['COMPOSICAO'] ."</td>";
                    echo "<td>". $row['EFEITOS'] ."</td>";

                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>Nenhum registro encontrado</td></tr>";
            }

            $conn->close(); // fecha a conexão
            ?>
        </tbody>
    </table>
</div>

</body>
</html>