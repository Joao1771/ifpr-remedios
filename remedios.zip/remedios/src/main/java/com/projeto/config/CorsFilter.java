package com.projeto.config;

import java.io.IOException;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.ext.Provider;

// Classe para o CORS não bloquear o localhost
@Provider
public class CorsFilter implements ContainerResponseFilter {

    @Override
    public void filter(ContainerRequestContext requestContext,
                       ContainerResponseContext responseContext)
            throws IOException {

        responseContext.getHeaders().add(
                "Access-Control-Allow-Origin",
                "http://localhost" //url de origem permitida
        );

        responseContext.getHeaders().add(
                "Access-Control-Allow-Headers",
                "origin, content-type, accept, authorization" //headers permitidos
        );

        responseContext.getHeaders().add(
                "Access-Control-Allow-Credentials",//permite credenciais
                "true"
        );

        responseContext.getHeaders().add(
                "Access-Control-Allow-Methods",
                "GET, POST, PUT, DELETE, OPTIONS, HEAD" //métodos permitidos
        );
    }
}