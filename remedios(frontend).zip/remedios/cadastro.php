<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <title>Enfermagem</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="caminho/do/arquivo.js"></script>
  </head>

  <body>

    <div id = "centralizarCadastro">

    <img id = "imagemLogo"
      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAulBMVEX///8uplDSJC0wp1IlpEsboUSz3r/O6tY8q1rm9eun2LTg8uag1K4kpEq64cX8/vxRs2zw+fLW7t1xvIN4wIliunnRGCPRHiju+PH54uPRFiFCr2HVKDPYPUbkgYX99fXYRUzmjpLzy8376+zgbXLY796GyplrvoLrn6Pkh4vgdnvien7ur7L429zeZGrQCxryxMfbV12W0KXzx8rpmJvwtrnVMjveaG3pnaDaTVXD5c1Ps2qCyZVat3QtStloAAAFWElEQVR4nO2d6XayOhhGUYI4IaWtIOBQ5w5S1NP2fNV6/7d19DuCaB3edJHSdD37N8+CbSIk8iYqCgAAAAAA+L30e/cPj4PB41N3EnSyvpj0CSbPzTD07DWeF3qt9rSf9SWlStBt2XY+gePlZ5PjDalXKSzMZKZSpmQKDVF+btuxnfwhjt064mh9MIPEuBJnzHKRlvFrYgQnd94nva3jIDg8eK7laBj1OLNgjJZhxZIAv043/7n9IuzWdP/okk+82FxOG0ahG4Ocmacv2H8+0YDbZmze7x2uq9SLzWmFbca6In8qxm36goOzgmtFZyK1Yed8C/6vmGxF6Qy7FwU3HbUnr+Hkst8a+3338JfM0L07fRfdU3yQ1bBN6KMH/VQuw4Dmt2nEmZyGXfuyW6QYNaJUhkGL9i3c4LVlNJzQmzDvvLsSGj5zGObzU/kMO016J1130wf5DHshTxM6M/kM7/kMmx3pDClD0gS2K53hE59h2JPO8JHrVpoP/4HhjzN84jSUr5dSJxaRYSCd4QufYb4vneEr3/OwJd/z0OX6HtoDRTpDhfgTxtbwXkLDB44vovPWk9Cw1+Rown87Ehr2n+ndNIx+FZbKUHkl32uct+g1m1yGHfK9xnuJMnIZKq9EQ2cW/+gtmWGnTeunzd1LRMkMFfedoujtftSXzlDpvV3uqM4g8TZfOkNlcuYV97YFZ27iePkMlekFxcRdRlJD5bV15rvohAN37+ghh+FimzFXdMMPAYZKMHNONaPT7B5U1Jh16tUy1YpC5AqVnCamoKbzp3V0EO54z9NPB+s+rXSEqeU406gbpM+FiWnCDcFj3jtoR8f27u6Plbbp46JKYJUs+yqNfErGr1pHTpgS7sus6UWlX47j2a3HE2Vt6ztHw7pE4/BSzYuRNebR06VGv/dn0Gp6YRjab+/tX1l/uaHvBkHg/lI5AAAQxLBGYLFffl1aUEKVE2f8Xkq3KmE0xZhf2D2LzapPqGlmTB0JK0unY46JI2KW2w2Iy7QhpqhpAh86eVLDllHGWtLrvLPvqFVygXmORTX0PDNgQUsLOKiSm+NrhoWzZ/8OYAhDGMJQPDCEIQxhKB4YwhCGMBQPDGEIQxiKB4YwhCEMxQNDGMIQhuKBIQxhmL1hmf4ePxeVjlxL9R5fJ1+ssYoyHLUYhogdAjkZERuRFRdxppajKTImYINAbqy5qlFY7gQVs+CTMqrImm0OrOH1ZQ4qf0xKZvgz/AAAAAAKZoXAwejLLFFCB2uYSJn0n6Fm+apIwB9fJ0KLMSVTXNUSjpUPn5JZztN2nBNrtg1f3wmqxPWHrBpnSlcabf2hNk53+Rp9xSuLdx83V9QpF4tnXDxrSNOdU37X/JBnHXC6K52/a46f3VpuGMIQhjCEIQxhCEMYwhCGMIQhDGEIQxjCEIYwhCEMYQhDGMIQhjCEIQx5Dc3MDBf0Pff8qApErv9WN+vkypHd3txzasYYxxmdsgHl3/P4KVe/V+qkkm3NmO8KeayRQQuNExdboNWT7xWUp4OplwkU9j/YSoES0vcyFimzELyhNwAAAHACk8BXQhmoHGU4qhMYl5Pl140qJVMfZb8T9JqaajACRnIEVrnSKBmm+amPwPhpkOcJxigO3ZJH6372XbVAr/OO/9mo8oX/e8qO37+WG4YwhCEMxQNDGMIQhuKBIQxhCEPxwBCGMISheGAIQxjCUDwwhCEMYSgeGMIQhj/AUPD/cmdvKLpSQT979u+gQd59PFFt8kGuNllmX22i1IoaqWRor2JoRcoYmp99E66pjG4I3JaTrWGVKZmb+Q/Ycx4AAAAAAGTKfyux7rZjlWS4AAAAAElFTkSuQmCC"
      alt="IFPR Londrina"
    >

   
      <h2 id = "cadastroDeAcesso">
        CADASTRO DE ACESSO
      </h2>

 
      <form action="arquivosPHP/cadastrar.php" method="post" style="width: 100%; max-width: 500px;">

        <div  id = "bordaDosInputs">

          <label class="form-label">Nome</label>

          <input
            type="text"
            class="form-control"
            style="margin-bottom:25px; height: 45px;"
            name="nome"
            placeholder="Digite seu nome"
            required
          >

          <label class="form-label">Senha</label>

          <input
            type="password"
            class="form-control"
            style="margin-bottom:25px; height: 45px;"
            name="senha"
            placeholder="Digite sua senha"
            required
          >

          <button
            class="btn btn-primary"
            style="width: 100%;
              height: 45px;
              background-color: #2f9e41;
              border: none;
              font-weight: 600;
            "
            type="submit">
            Enviar
          </button>

        </div>

      </form>

    </div>

  </body>
</html>

